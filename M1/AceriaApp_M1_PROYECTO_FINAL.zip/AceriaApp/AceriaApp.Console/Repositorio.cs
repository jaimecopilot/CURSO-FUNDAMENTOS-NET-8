using System.Diagnostics.CodeAnalysis;

namespace AceriaApp.Console;

public class Repositorio<T> where T : class, IPlancha
{
    private readonly List<T> elementos = new();

    public event EventHandler<ElementoAgregadoEventArgs<T>>? ElementoAgregado;

    public void Agregar(T elemento)
    {
        ArgumentNullException.ThrowIfNull(elemento);

        if (BuscarPorNumeroSinExcepcion(elemento.Numero) is not null)
            throw new PlanchaDuplicadaException(elemento.Numero);

        elementos.Add(elemento);
        OnElementoAgregado(elemento);
    }

    protected virtual void OnElementoAgregado(T elemento)
    {
        ElementoAgregado?.Invoke(this, new ElementoAgregadoEventArgs<T>(elemento));
    }

    public T BuscarPorNumero(string numero)
    {
        var elemento = BuscarPorNumeroSinExcepcion(numero);
        return elemento ?? throw new PlanchaNoEncontradaException(numero);
    }

    private T? BuscarPorNumeroSinExcepcion(string numero)
    {
        foreach (var elemento in elementos)
        {
            if (elemento.Numero == numero)
                return elemento;
        }
        return null;
    }

    public IReadOnlyList<T> Listar() => elementos.AsReadOnly();
    public int Cantidad() => elementos.Count;

    public void Eliminar(string numero)
    {
        var elemento = BuscarPorNumero(numero);
        elementos.Remove(elemento);
    }

    public IEnumerable<T> Filtrar(Func<T, bool> criterio)
    {
        ArgumentNullException.ThrowIfNull(criterio);
        return elementos.Where(criterio);
    }

    public bool TryBuscarPorNumero(string numero, [NotNullWhen(true)] out T? elemento)
    {
        elemento = BuscarPorNumeroSinExcepcion(numero);
        return elemento is not null;
    }
}
