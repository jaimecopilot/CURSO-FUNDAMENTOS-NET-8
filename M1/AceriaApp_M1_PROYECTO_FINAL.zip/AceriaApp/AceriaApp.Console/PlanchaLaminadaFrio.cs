namespace AceriaApp.Console;

public sealed class PlanchaLaminadaFrio : PlanchaAcero, IReciclable
{
    public double ReduccionPorcentaje { get; set; }

    public PlanchaLaminadaFrio(string numero, double pesoKg, double espesorMm, double anchoMm, double largoMm, string estado, double reduccionPorcentaje)
        : base(numero, pesoKg, espesorMm, anchoMm, largoMm, estado)
    {
        ReduccionPorcentaje = reduccionPorcentaje;
    }

    public override double CalcularCostoExtra() => 25.0;
    public double PorcentajeReciclable() => 90.0;

    public override void MostrarInformacion()
    {
        base.MostrarInformacion();
        global::System.Console.WriteLine(
            $"  Tipo: Laminada en frío, Reducción: {ReduccionPorcentaje:N1}%, Costo extra: {CalcularCostoExtra():C}");
    }
}
