namespace AceriaApp.Console;

public static class FiltrosPlancha
{
    public static IEnumerable<IPlancha> FiltrarConDelegado(
        IEnumerable<IPlancha> planchas, CriterioPlancha criterio)
    {
        ArgumentNullException.ThrowIfNull(planchas);
        ArgumentNullException.ThrowIfNull(criterio);

        foreach (var plancha in planchas)
        {
            if (criterio(plancha))
                yield return plancha;
        }
    }
}
