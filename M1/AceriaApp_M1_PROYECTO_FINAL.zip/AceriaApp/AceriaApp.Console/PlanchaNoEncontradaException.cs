namespace AceriaApp.Console;

public sealed class PlanchaNoEncontradaException : Exception
{
    public string NumeroBuscado { get; }

    public PlanchaNoEncontradaException(string numeroBuscado)
        : base($"No se encontró la plancha con número {numeroBuscado}.")
    {
        NumeroBuscado = numeroBuscado;
    }

    public PlanchaNoEncontradaException(string numeroBuscado, Exception innerException)
        : base($"No se encontró la plancha con número {numeroBuscado}.", innerException)
    {
        NumeroBuscado = numeroBuscado;
    }
}
