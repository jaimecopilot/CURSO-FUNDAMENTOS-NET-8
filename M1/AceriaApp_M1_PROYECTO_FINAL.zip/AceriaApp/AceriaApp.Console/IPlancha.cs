namespace AceriaApp.Console;

public interface IPlancha
{
    string Numero { get; }
    double PesoKg { get; }
    double EspesorMm { get; }
    double AnchoMm { get; }
    double LargoMm { get; }
    string Estado { get; }

    double CalcularVolumen();
    double CalcularCostoExtra();
    void MostrarInformacion();

    string ObtenerDescripcionCorta() => $"{Numero} - {PesoKg:N1} kg";
}
