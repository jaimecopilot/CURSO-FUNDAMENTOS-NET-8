namespace AceriaApp.Console;

public delegate bool CriterioPlancha(IPlancha plancha);
