namespace AceriaApp.Console;

public sealed class ElementoAgregadoEventArgs<T> : EventArgs where T : class, IPlancha
{
    public T Elemento { get; }

    public ElementoAgregadoEventArgs(T elemento)
    {
        Elemento = elemento ?? throw new ArgumentNullException(nameof(elemento));
    }
}
