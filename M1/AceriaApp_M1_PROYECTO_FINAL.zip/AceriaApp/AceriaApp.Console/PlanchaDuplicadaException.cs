namespace AceriaApp.Console;

public sealed class PlanchaDuplicadaException : Exception
{
    public string NumeroDuplicado { get; }

    public PlanchaDuplicadaException(string numeroDuplicado)
        : base($"Ya existe una plancha con número {numeroDuplicado}.")
    {
        NumeroDuplicado = numeroDuplicado;
    }
}
