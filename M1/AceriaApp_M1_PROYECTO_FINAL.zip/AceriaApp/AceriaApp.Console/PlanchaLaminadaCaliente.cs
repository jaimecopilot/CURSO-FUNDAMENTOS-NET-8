namespace AceriaApp.Console;

public sealed class PlanchaLaminadaCaliente : PlanchaAcero
{
    public double TemperaturaLaminacionC { get; set; }

    public PlanchaLaminadaCaliente(string numero, double pesoKg, double espesorMm, double anchoMm, double largoMm, string estado, double temperaturaLaminacionC)
        : base(numero, pesoKg, espesorMm, anchoMm, largoMm, estado)
    {
        TemperaturaLaminacionC = temperaturaLaminacionC;
    }

    public override double CalcularCostoExtra() => 15.0;

    public override void MostrarInformacion()
    {
        base.MostrarInformacion();
        global::System.Console.WriteLine(
            $"  Tipo: Laminada en caliente, Temperatura: {TemperaturaLaminacionC:N0} °C, Costo extra: {CalcularCostoExtra():C}");
    }
}
