namespace AceriaApp.Console;

public abstract class PlanchaAcero : IPlancha, IInspeccionable
{
    private string numero = string.Empty;
    private double pesoKg;
    private double espesorMm;
    private double anchoMm;
    private double largoMm;
    private string estado = string.Empty;

    public string Numero
    {
        get => numero;
        private set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("El número de plancha no puede estar vacío.", nameof(value));
            numero = value;
        }
    }

    public double PesoKg
    {
        get => pesoKg;
        set
        {
            if (value <= 0)
                throw new PesoInvalidoException(value);
            pesoKg = value;
        }
    }

    public double EspesorMm
    {
        get => espesorMm;
        set
        {
            if (value <= 0)
                throw new ArgumentOutOfRangeException(nameof(value), "El espesor debe ser mayor que cero.");
            espesorMm = value;
        }
    }

    public double AnchoMm
    {
        get => anchoMm;
        set
        {
            if (value <= 0)
                throw new ArgumentOutOfRangeException(nameof(value), "El ancho debe ser mayor que cero.");
            anchoMm = value;
        }
    }

    public double LargoMm
    {
        get => largoMm;
        set
        {
            if (value <= 0)
                throw new ArgumentOutOfRangeException(nameof(value), "El largo debe ser mayor que cero.");
            largoMm = value;
        }
    }

    public string Estado
    {
        get => estado;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("El estado no puede estar vacío.", nameof(value));
            estado = value;
        }
    }

    protected PlanchaAcero(string numero, double pesoKg, double espesorMm, double anchoMm, double largoMm, string estado)
    {
        Numero = numero;
        PesoKg = pesoKg;
        EspesorMm = espesorMm;
        AnchoMm = anchoMm;
        LargoMm = largoMm;
        Estado = estado;
    }

    public double VolumenM3 => (EspesorMm / 1000.0) * (AnchoMm / 1000.0) * (LargoMm / 1000.0);
    public double CalcularVolumen() => VolumenM3;
    public abstract double CalcularCostoExtra();

    public virtual void MostrarInformacion()
    {
        global::System.Console.WriteLine(
            $"Plancha {Numero}: {PesoKg:N1} kg, {EspesorMm} mm x {AnchoMm} mm x {LargoMm} mm, Estado: {Estado}");
    }

    public bool RequiereInspeccion() => PesoKg > 200.0;
}
