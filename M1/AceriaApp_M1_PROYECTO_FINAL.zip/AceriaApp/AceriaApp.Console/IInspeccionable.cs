namespace AceriaApp.Console;

public interface IInspeccionable
{
    bool RequiereInspeccion();
}
