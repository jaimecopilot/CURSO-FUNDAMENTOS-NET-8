namespace AceriaApp.Console;

public interface IReciclable
{
    double PorcentajeReciclable();
}
