namespace AceriaApp.Console;

public sealed class PlanchaGalvanizada : PlanchaAcero, IReciclable
{
    public double CapaZincMicras { get; set; }

    public PlanchaGalvanizada(string numero, double pesoKg, double espesorMm, double anchoMm, double largoMm, string estado, double capaZincMicras)
        : base(numero, pesoKg, espesorMm, anchoMm, largoMm, estado)
    {
        CapaZincMicras = capaZincMicras;
    }

    public override double CalcularCostoExtra() => 35.0;
    public double PorcentajeReciclable() => 85.0;

    public override void MostrarInformacion()
    {
        base.MostrarInformacion();
        global::System.Console.WriteLine(
            $"  Tipo: Galvanizada, Capa de zinc: {CapaZincMicras:N1} micras, Costo extra: {CalcularCostoExtra():C}");
    }
}
