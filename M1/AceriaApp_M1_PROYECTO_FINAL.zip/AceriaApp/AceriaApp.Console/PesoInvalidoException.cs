namespace AceriaApp.Console;

public sealed class PesoInvalidoException : Exception
{
    public double PesoIntentado { get; }

    public PesoInvalidoException(double pesoIntentado)
        : base($"El peso {pesoIntentado} kg no es válido. Debe ser mayor que cero.")
    {
        PesoIntentado = pesoIntentado;
    }
}
