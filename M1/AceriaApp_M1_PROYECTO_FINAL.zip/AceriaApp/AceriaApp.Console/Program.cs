using AceriaApp.Console;

global::System.Console.WriteLine("=== ACERIA APP - ESTADO FINAL DEL MÓDULO 1 ===");

var repositorio = new Repositorio<IPlancha>();
repositorio.ElementoAgregado += (_, args) =>
    global::System.Console.WriteLine($"Elemento agregado: {args.Elemento.Numero}");

var planchasIniciales = new IPlancha[]
{
    new PlanchaLaminadaCaliente("PC-001", 210.5, 6.0, 1500.0, 3000.0, "Aprobada", 1050.0),
    new PlanchaLaminadaFrio("PF-001", 195.2, 5.0, 1200.0, 2500.0, "Rechazada", 30.0),
    new PlanchaLaminadaCaliente("PC-002", 225.0, 8.0, 1800.0, 3200.0, "Aprobada", 1100.0),
    new PlanchaLaminadaFrio("PF-002", 205.0, 6.5, 1400.0, 2800.0, "Aprobada", 25.0),
    new PlanchaGalvanizada("PG-001", 215.0, 7.0, 1600.0, 3100.0, "Aprobada", 20.0)
};

foreach (var plancha in planchasIniciales)
    repositorio.Agregar(plancha);

global::System.Console.WriteLine("\n--- Polimorfismo e interfaces ---");
foreach (var plancha in repositorio.Listar())
{
    plancha.MostrarInformacion();
    global::System.Console.WriteLine($"  {plancha.ObtenerDescripcionCorta()}");

    if (plancha is IInspeccionable inspeccionable)
        global::System.Console.WriteLine($"  Requiere inspección: {inspeccionable.RequiereInspeccion()}");

    if (plancha is IReciclable reciclable)
        global::System.Console.WriteLine($"  Reciclable: {reciclable.PorcentajeReciclable():N1}%");
}

global::System.Console.WriteLine("\n--- LINQ ---");
var aprobadas = repositorio.Listar().Where(p => p.Estado == "Aprobada");
var ordenadas = aprobadas.OrderByDescending(p => p.PesoKg).ToList();
foreach (var plancha in ordenadas)
    global::System.Console.WriteLine($"{plancha.Numero}: {plancha.PesoKg:N1} kg");

var porEstado = repositorio.Listar()
    .GroupBy(p => p.Estado)
    .Select(g => new { Estado = g.Key, Cantidad = g.Count(), Peso = g.Sum(p => p.PesoKg) });
foreach (var grupo in porEstado)
    global::System.Console.WriteLine($"{grupo.Estado}: {grupo.Cantidad} planchas, {grupo.Peso:N1} kg");

global::System.Console.WriteLine($"Peso medio: {repositorio.Listar().Average(p => p.PesoKg):N1} kg");
global::System.Console.WriteLine($"Existe alguna pesada: {repositorio.Listar().Any(p => p.PesoKg > 220)}");
global::System.Console.WriteLine($"Todas tienen peso positivo: {repositorio.Listar().All(p => p.PesoKg > 0)}");

global::System.Console.WriteLine("\n--- Delegados y lambdas ---");
Func<IPlancha, bool> criterio = p => p.PesoKg >= 210.0;
Action<IPlancha> mostrar = p => global::System.Console.WriteLine($"{p.Numero}: {p.PesoKg:N1} kg - {p.Estado}");
foreach (var plancha in repositorio.Filtrar(criterio))
    mostrar(plancha);

CriterioPlancha criterioPersonalizado = p => p.Estado == "Aprobada" && p.PesoKg > 210.0;
foreach (var plancha in FiltrosPlancha.FiltrarConDelegado(repositorio.Listar(), criterioPersonalizado))
    global::System.Console.WriteLine($"Delegado personalizado: {plancha.Numero}");

EventHandler<ElementoAgregadoEventArgs<IPlancha>> secundario = (_, args) =>
    global::System.Console.WriteLine($"Manejador secundario: {args.Elemento.Numero}");
repositorio.ElementoAgregado += secundario;
repositorio.Agregar(new PlanchaGalvanizada("PG-002", 190.0, 5.5, 1300.0, 2600.0, "Rechazada", 18.0));
repositorio.ElementoAgregado -= secundario;

global::System.Console.WriteLine("\n--- Excepciones ---");
try
{
    repositorio.Agregar(new PlanchaGalvanizada("PG-001", 215.0, 7.0, 1600.0, 3100.0, "Aprobada", 20.0));
}
catch (PlanchaDuplicadaException ex)
{
    global::System.Console.WriteLine($"Duplicado controlado: {ex.Message}");
}

try
{
    _ = repositorio.BuscarPorNumero("XX-999");
}
catch (PlanchaNoEncontradaException ex)
{
    global::System.Console.WriteLine($"No encontrada: {ex.Message}");
}

try
{
    _ = new PlanchaLaminadaFrio("PF-ERR", -5.0, 5.0, 1200.0, 2500.0, "Rechazada", 30.0);
}
catch (PesoInvalidoException ex)
{
    global::System.Console.WriteLine($"Peso inválido: {ex.PesoIntentado:N1} kg");
}

global::System.Console.WriteLine("\n--- Nullable reference types ---");
IPlancha? buscada = repositorio.Listar().FirstOrDefault(p => p.Numero == "XX-999");
string? numeroSeguro = buscada?.Numero;
global::System.Console.WriteLine($"Número seguro: {numeroSeguro ?? "No encontrada"}");

string? descripcion = null;
descripcion ??= "Descripción por defecto";
global::System.Console.WriteLine($"Descripción: {descripcion}");

IPlancha? conocida = repositorio.Listar().FirstOrDefault(p => p.Numero == "PC-001");
if (conocida is not null)
{
    string numeroConSupresion = conocida!.Numero; // ! es redundante aquí, se incluye para mostrar el operador sin riesgo.
    global::System.Console.WriteLine($"Número con supresión controlada: {numeroConSupresion}");
}

if (repositorio.TryBuscarPorNumero("PC-001", out IPlancha? encontrada))
    global::System.Console.WriteLine($"TryBuscarPorNumero: {encontrada.Numero}");

global::System.Console.WriteLine($"\nTotal final de planchas: {repositorio.Cantidad()}");
